/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './*.php', // Adjust the path according to your project structure
    './**/*.php',
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}

